﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MediatorDesignPatternDemo.Services
{
    public interface IShoppingMediator
    {
        void Handle(int id);
    }

    public class ShoppingMediator : IShoppingMediator
    {
        private readonly IProductService _productService;
        private readonly INotificationService _notificationService;
        private readonly IShoppingService _shoppingService;

        public ShoppingMediator(
            IProductService productService, 
            INotificationService notificationService, 
            IShoppingService shoppingService)
        {
            _productService = productService;
            _notificationService = notificationService;
            _shoppingService = shoppingService;
        }

        public void Handle(int id)
        {
            // Fetch Product from Database
            var product = _productService.GetProduct(id);

            // Add Product to Basket
            _shoppingService.AddToBasket(product);

            // Send Notification to User
            _notificationService.SendNotification(product);
        }
    }
}
