﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatorDesignPatternDemo.Models;

namespace MediatorDesignPatternDemo.Services
{
    public interface IProductService
    {
        Product GetProduct(int id);
    }

    public class ProductService : IProductService
    {
        public Product GetProduct(int id)
        {
            // In real world application you will fetch Product from database
            // using some backend service or repository and return 

            return new Product(){ Id = id, Name = "Dell Laptop", Price = 800 };
        }
    }
}
