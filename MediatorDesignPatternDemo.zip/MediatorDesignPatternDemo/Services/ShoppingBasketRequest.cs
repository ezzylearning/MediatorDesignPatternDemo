﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MediatorDesignPatternDemo.Models;
using MediatR;

namespace MediatorDesignPatternDemo.Services
{
    public class ShoppingBasketRequest: IRequest 
    {
        public int ProductId { get; set; } 
    }

    public class ShoppingBasketRequestHandler : RequestHandler<ShoppingBasketRequest>
    {
        private readonly IProductService _productService;
        private readonly INotificationService _notificationService;
        private readonly IShoppingService _shoppingService;

        public ShoppingBasketRequestHandler(
            IProductService productService, 
            INotificationService notificationService, 
            IShoppingService shoppingService)
        {
            _productService = productService;
            _notificationService = notificationService;
            _shoppingService = shoppingService;
        } 

        protected override void Handle(ShoppingBasketRequest request)
        {
            // Fetch Product from Database
            var product = _productService.GetProduct(request.ProductId);

            // Add Product To Basket
            _shoppingService.AddToBasket(product);

            // Send Notification to User
            _notificationService.SendNotification(product);
        }
    }
}
