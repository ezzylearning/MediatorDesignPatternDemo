﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatorDesignPatternDemo.Models;

namespace MediatorDesignPatternDemo.Services
{
    public interface INotificationService
    {
        void SendNotification(Product product);
    }

    public class NotificationService : INotificationService
    {
        public void SendNotification(Product product)
        {
            // Implement the code to send an email notification 
            // with the product details to customer
        }
    }
}
