﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatorDesignPatternDemo.Models;

namespace MediatorDesignPatternDemo.Services
{
    public interface IShoppingService
    {
        void AddToBasket(Product product);
    }

    public class ShoppingService : IShoppingService
    {
        public void AddToBasket(Product product)
        {
            // Implement the code to add the product to a basket.
        }
    }
}
