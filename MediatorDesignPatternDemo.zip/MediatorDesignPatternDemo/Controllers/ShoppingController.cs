﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatorDesignPatternDemo.Services;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace MediatorDesignPatternDemo.Controllers
{
    public class ShoppingController : Controller
    {
        //private readonly IProductService _productService;
        //private readonly INotificationService _notificationService;
        //private readonly IShoppingService _shoppingService;

        //public ShoppingController(
        //    IProductService productService,
        //    INotificationService notificationService,
        //    IShoppingService shoppingService)
        //{
        //    _productService = productService;
        //    _notificationService = notificationService;
        //    _shoppingService = shoppingService;
        //}

        //[HttpPost]
        //public IActionResult AddToBasket(int id)
        //{
        //    // Fetch Product from Database
        //    var product = _productService.GetProduct(id);

        //    // Add Product To Basket
        //    _shoppingService.AddToBasket(product);

        //    // Send Notification to User
        //    _notificationService.SendNotification(product);

        //    return View();
        //}

        //-------------------------------------------------------------------------------------------------

        //private readonly IShoppingMediator _shoppingMediator;

        //public ShoppingController(IShoppingMediator shoppingMediator)
        //{
        //    _shoppingMediator = shoppingMediator;
        //}

        //[HttpPost]
        //public IActionResult AddToBasket(int id)
        //{
        //    _shoppingMediator.Handle(id);

        //    return View();
        //}

        //-------------------------------------------------------------------------------------------------

        protected readonly IMediator _mediator;

        public ShoppingController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPost]
        public IActionResult AddToBasket(int id)
        {
            _mediator.Send(new ShoppingBasketRequest() { ProductId = id });

            return View();
        }

    }
}
